import os
import uuid
import logging
import sqlite3
from datetime import datetime, timedelta
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from dotenv import load_dotenv
import google.generativeai as genai
from werkzeug.utils import secure_filename

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Load environment variables
try:
    load_dotenv()
    logger.info("Loaded .env file successfully")
except Exception as e:
    logger.warning(f"Could not load .env file: {str(e)}")

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.urandom(24)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
CORS(app, supports_credentials=True)

# Ensure upload folder exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Get Gemini API key
api_key = os.getenv('GEMINI_API_KEY') or "AIzaSyCbIedyqraZAZV_Dm8iN0H6wp2Ek1yiTcU"
logger.info("Using %s API key", "environment variable" if os.getenv('GEMINI_API_KEY') else "hardcoded")

# Configure Gemini API
genai.configure(api_key=api_key)

# SQLite Database Setup
DB_FILE = 'chatbot.db'

def init_db():
    with sqlite3.connect(DB_FILE) as conn:
        c = conn.cursor()
        c.execute('''
            CREATE TABLE IF NOT EXISTS chat_history (
                id TEXT PRIMARY KEY,
                session_id TEXT,
                timestamp TEXT,
                message TEXT,
                is_user INTEGER,
                reactions TEXT
            )
        ''')
        c.execute('''
            CREATE TABLE IF NOT EXISTS user_profiles (
                session_id TEXT PRIMARY KEY,
                name TEXT,
                skill TEXT,
                topics TEXT,
                points INTEGER
            )
        ''')
        c.execute('''
            CREATE TABLE IF NOT EXISTS reminders (
                id TEXT PRIMARY KEY,
                session_id TEXT,
                task TEXT,
                time TEXT
            )
        ''')
        conn.commit()
    logger.info("Database initialized")

init_db()

ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# System prompt
SYSTEM_PROMPT = """You are a Digital Marketing Expert Bot designed to educate users on all aspects of digital marketing. You have four main modes of interaction:

1. INFORMATION MODE: When users ask general questions about digital marketing topics, provide clear, concise, and educational responses tailored to their skill level (beginner, intermediate, advanced) and preferred topics if provided. Keep explanations brief (150-200 words) and focus on key points. Topics include SEO, social media marketing, content marketing, email marketing, PPC advertising, influencer marketing, analytics, conversion optimization, marketing automation, branding, e-commerce marketing, mobile marketing, video marketing, and digital marketing strategies.

2. QUIZ MODE: When users request a quiz or question (using words like "quiz", "test me", "give me a question"), provide a multiple-choice (A, B, C, D) or true/false question. If the user responds with an answer (e.g., "A", "True"), evaluate it, provide feedback, and award 10 points for correct answers. If they earn 50 points, award a badge (e.g., "Quiz Master").

3. PLAN MODE: When users provide marketing plan details (business, audience, goals, budget, channels), generate a structured marketing plan in HTML format with sections for Overview, Strategy, and Timeline.

4. TRANSLATION MODE: If a language is specified (e.g., 'es' for Spanish, 'fr' for French), translate user input to English for processing and translate the response back to the specified language. Ensure responses are culturally appropriate.

COMPARISON FORMAT: For comparison questions (e.g., "What's the difference between SEO and PPC?"), use an HTML table with bullet points.

Maintain conversation context. Use a friendly, engaging tone. Use bullet points for clarity. If a user profile is provided, tailor responses to their skill level and topics. For quiz answers, include points and badge information in the response."""

@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

@app.route('/chat', methods=['POST'])
def chat():
    try:
        data = request.json
        user_message = data.get('message', '')
        profile = data.get('profile', {})
        language = data.get('language', 'en')
        session_id = request.cookies.get('session_id') or str(uuid.uuid4())

        if not user_message:
            return jsonify({'response': 'Please provide a message', 'session_id': session_id}), 400

        # Initialize chat session
        model = genai.GenerativeModel('gemini-1.5-flash')
        chat_session = model.start_chat(history=[])
        chat_session.send_message(SYSTEM_PROMPT)

        # Translate input if not English
        if language != 'en':
            translation_prompt = f"Translate '{user_message}' from {language} to English."
            user_message = model.generate_content(translation_prompt).text

        # Store user message
        message_id = str(uuid.uuid4())
        with sqlite3.connect(DB_FILE) as conn:
            c = conn.cursor()
            c.execute('''
                INSERT INTO chat_history (id, session_id, timestamp, message, is_user, reactions)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (message_id, session_id, datetime.utcnow().isoformat(), user_message, 1, '[]'))
            conn.commit()

        # Generate response
        response = chat_session.send_message(user_message)
        response_text = response.text

        # Translate response if not English
        if language != 'en':
            translation_prompt = f"Translate '{response_text}' from English to {language}."
            response_text = model.generate_content(translation_prompt).text

        bot_message_id = str(uuid.uuid4())
        points = 0
        badge = None

        # Check for quiz answer
        with sqlite3.connect(DB_FILE) as conn:
            c = conn.cursor()
            c.execute('''
                SELECT message FROM chat_history
                WHERE session_id = ? AND is_user = 0
                ORDER BY timestamp DESC LIMIT 1
            ''', (session_id,))
            last_bot_message = c.fetchone()
            if last_bot_message and user_message in ['A', 'B', 'C', 'D', 'True', 'False'] and '?' in last_bot_message[0]:
                points = 10 if 'Correct' in response_text else 0
                c.execute('''
                    UPDATE user_profiles SET points = points + ? WHERE session_id = ?
                ''', (points, session_id))
                c.execute('SELECT points FROM user_profiles WHERE session_id = ?', (session_id,))
                total_points = c.fetchone()[0]
                if total_points >= 50 and not badge:
                    badge = 'Quiz Master'
                    c.execute('UPDATE user_profiles SET points = 0 WHERE session_id = ?', (session_id,))
                conn.commit()

        # Store bot response
        with sqlite3.connect(DB_FILE) as conn:
            c = conn.cursor()
            c.execute('''
                INSERT INTO chat_history (id, session_id, timestamp, message, is_user, reactions)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (bot_message_id, session_id, datetime.utcnow().isoformat(), response_text, 0, '[]'))
            conn.commit()

        cleanup_old_sessions()

        resp = jsonify({
            'response': response_text,
            'session_id': session_id,
            'message_id': bot_message_id,
            'points': points,
            'badge': badge
        })
        resp.set_cookie('session_id', session_id, max_age=3600, httponly=True, samesite='Strict')
        return resp

    except Exception as e:
        logger.error(f"Chat error: {str(e)}")
        return jsonify({'response': f'Sorry, I encountered an error: {str(e)}', 'session_id': session_id}), 500

@app.route('/upload', methods=['POST'])
def upload_file():
    try:
        session_id = request.cookies.get('session_id') or str(uuid.uuid4())
        if 'file' not in request.files:
            return jsonify({'response': 'No file provided', 'session_id': session_id}), 400

        file = request.files['file']
        if file.filename == '':
            return jsonify({'response': 'No file selected', 'session_id': session_id}), 400

        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
            logger.info(f"File uploaded: {filename}")

            response = f"File '{filename}' uploaded successfully. Analysis feature coming soon!"
            with sqlite3.connect(DB_FILE) as conn:
                c = conn.cursor()
                c.execute('''
                    INSERT INTO chat_history (id, session_id, timestamp, message, is_user, reactions)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (str(uuid.uuid4()), session_id, datetime.utcnow().isoformat(), f"Uploaded file: {filename}", 1, '[]'))
                c.execute('''
                    INSERT INTO chat_history (id, session_id, timestamp, message, is_user, reactions)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (str(uuid.uuid4()), session_id, datetime.utcnow().isoformat(), response, 0, '[]'))
                conn.commit()

            resp = jsonify({'response': response, 'session_id': session_id})
            resp.set_cookie('session_id', session_id, max_age=3600, httponly=True, samesite='Strict')
            return resp

        return jsonify({'response': 'Invalid file type', 'session_id': session_id}), 400

    except Exception as e:
        logger.error(f"Upload error: {str(e)}")
        return jsonify({'response': f'Sorry, I encountered an error: {str(e)}', 'session_id': session_id}), 500

@app.route('/history', methods=['GET'])
def get_history():
    try:
        session_id = request.cookies.get('session_id')
        if not session_id:
            return jsonify({'history': [], 'session_id': session_id}), 200

        with sqlite3.connect(DB_FILE) as conn:
            c = conn.cursor()
            c.execute('''
                SELECT id, timestamp, message, is_user, reactions
                FROM chat_history
                WHERE session_id = ?
                ORDER BY timestamp
            ''', (session_id,))
            history = [
                {'id': row[0], 'timestamp': row[1], 'message': row[2], 'is_user': bool(row[3]), 'reactions': row[4]}
                for row in c.fetchall()
            ]

        return jsonify({'history': history, 'session_id': session_id})

    except Exception as e:
        logger.error(f"History error: {str(e)}")
        return jsonify({'response': f'Sorry, I encountered an error: {str(e)}', 'session_id': session_id}), 500

@app.route('/react', methods=['POST'])
def add_reaction():
    try:
        data = request.json
        session_id = request.cookies.get('session_id') or str(uuid.uuid4())
        message_id = data.get('message_id')
        reaction = data.get('reaction')

        if not message_id or not reaction:
            return jsonify({'response': 'Missing message_id or reaction', 'session_id': session_id}), 400

        with sqlite3.connect(DB_FILE) as conn:
            c = conn.cursor()
            c.execute('SELECT reactions FROM chat_history WHERE id = ?', (message_id,))
            result = c.fetchone()
            if result:
                reactions = eval(result[0])  # Convert string to list
                reactions.append(reaction)
                c.execute('UPDATE chat_history SET reactions = ? WHERE id = ?', (str(reactions), message_id))
                conn.commit()
                logger.info(f"Added reaction {reaction} to message {message_id}")

        resp = jsonify({'response': f'Reaction {reaction} added', 'session_id': session_id})
        resp.set_cookie('session_id', session_id, max_age=3600, httponly=True, samesite='Strict')
        return resp

    except Exception as e:
        logger.error(f"Reaction error: {str(e)}")
        return jsonify({'response': f'Sorry, I encountered an error: {str(e)}', 'session_id': session_id}), 500

@app.route('/quick_action', methods=['POST'])
def quick_action():
    try:
        data = request.json
        action = data.get('action')
        session_id = request.cookies.get('session_id') or str(uuid.uuid4())

        if not action:
            return jsonify({'response': 'No action specified', 'session_id': session_id}), 400

        responses = {
            'Generate Report': 'Report generation feature coming soon!',
            'Analyze Data': 'Data analysis feature coming soon!',
            'Export Chat': 'Chat export feature coming soon!'
        }

        response = responses.get(action, 'Invalid action')
        with sqlite3.connect(DB_FILE) as conn:
            c = conn.cursor()
            c.execute('''
                INSERT INTO chat_history (id, session_id, timestamp, message, is_user, reactions)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (str(uuid.uuid4()), session_id, datetime.utcnow().isoformat(), f"Quick action: {action}", 1, '[]'))
            c.execute('''
                INSERT INTO chat_history (id, session_id, timestamp, message, is_user, reactions)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (str(uuid.uuid4()), session_id, datetime.utcnow().isoformat(), response, 0, '[]'))
            conn.commit()

        resp = jsonify({'response': response, 'session_id': session_id})
        resp.set_cookie('session_id', session_id, max_age=3600, httponly=True, samesite='Strict')
        return resp

    except Exception as e:
        logger.error(f"Quick action error: {str(e)}")
        return jsonify({'response': f'Sorry, I encountered an error: {str(e)}', 'session_id': session_id}), 500

@app.route('/profile', methods=['POST'])
def save_profile():
    try:
        data = request.json
        session_id = request.cookies.get('session_id') or str(uuid.uuid4())
        profile = {
            'name': data.get('name', ''),
            'skill': data.get('skill', 'beginner'),
            'topics': ','.join(data.get('topics', [])),
            'points': data.get('points', 0)
        }

        with sqlite3.connect(DB_FILE) as conn:
            c = conn.cursor()
            c.execute('''
                INSERT OR REPLACE INTO user_profiles (session_id, name, skill, topics, points)
                VALUES (?, ?, ?, ?, ?)
            ''', (session_id, profile['name'], profile['skill'], profile['topics'], profile['points']))
            conn.commit()
        logger.info(f"Saved profile for session {session_id}")

        resp = jsonify({'response': 'Profile saved successfully', 'session_id': session_id})
        resp.set_cookie('session_id', session_id, max_age=3600, httponly=True, samesite='Strict')
        return resp

    except Exception as e:
        logger.error(f"Profile error: {str(e)}")
        return jsonify({'response': f'Sorry, I encountered an error: {str(e)}', 'session_id': session_id}), 500

@app.route('/analyze', methods=['POST'])
def analyze_campaign():
    try:
        data = request.json
        session_id = request.cookies.get('session_id') or str(uuid.uuid4())
        ad_spend = float(data.get('ad_spend', 0))
        clicks = int(data.get('clicks', 0))
        conversions = int(data.get('conversions', 0))

        if not all([ad_spend, clicks, conversions]):
            return jsonify({'response': 'All fields are required', 'session_id': session_id}), 400

        cpc = ad_spend / clicks if clicks else 0
        conversion_rate = (conversions / clicks * 100) if clicks else 0
        cost_per_conversion = ad_spend / conversions if conversions else 0

        response = f"""
        <h4>Campaign Analysis</h4>
        <ul>
            <li><strong>Cost Per Click (CPC):</strong> ${cpc:.2f}</li>
            <li><strong>Conversion Rate:</strong> {conversion_rate:.2f}%</li>
            <li><strong>Cost Per Conversion:</strong> ${cost_per_conversion:.2f}</li>
            <li><strong>Suggestions:</strong>
                <ul>
                    <li>Optimize ad copy to improve click-through rates.</li>
                    <li>Test different landing pages to boost conversions.</li>
                    <li>Adjust targeting to reduce CPC.</li>
                </ul>
            </li>
        </ul>
        """

        with sqlite3.connect(DB_FILE) as conn:
            c = conn.cursor()
            c.execute('''
                INSERT INTO chat_history (id, session_id, timestamp, message, is_user, reactions)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (str(uuid.uuid4()), session_id, datetime.utcnow().isoformat(),
                  f"Campaign analysis: ${ad_spend}, {clicks} clicks, {conversions} conversions", 1, '[]'))
            c.execute('''
                INSERT INTO chat_history (id, session_id, timestamp, message, is_user, reactions)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (str(uuid.uuid4()), session_id, datetime.utcnow().isoformat(), response, 0, '[]'))
            conn.commit()

        resp = jsonify({'response': response, 'session_id': session_id})
        resp.set_cookie('session_id', session_id, max_age=3600, httponly=True, samesite='Strict')
        return resp

    except Exception as e:
        logger.error(f"Analyze error: {str(e)}")
        return jsonify({'response': f'Sorry, I encountered an error: {str(e)}', 'session_id': session_id}), 500

@app.route('/plan', methods=['POST'])
def generate_plan():
    try:
        data = request.json
        session_id = request.cookies.get('session_id') or str(uuid.uuid4())
        business = data.get('business', '')
        audience = data.get('audience', '')
        goals = data.get('goals', '')
        budget = float(data.get('budget', 0))
        channels = data.get('channels', '')

        if not all([business, audience, goals, budget, channels]):
            return jsonify({'response': 'All fields are required', 'session_id': session_id}), 400

        model = genai.GenerativeModel('gemini-1.5-flash')
        prompt = f"""
        Generate a digital marketing plan for:
        - Business: {business}
        - Target Audience: {audience}
        - Goals: {goals}
        - Budget: ${budget}
        - Channels: {channels}
        
        Format the response as an HTML structure with sections for Overview, Strategy, and Timeline.
        """
        response = model.generate_content(prompt).text

        with sqlite3.connect(DB_FILE) as conn:
            c = conn.cursor()
            c.execute('''
                INSERT INTO chat_history (id, session_id, timestamp, message, is_user, reactions)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (str(uuid.uuid4()), session_id, datetime.utcnow().isoformat(), 'Generated marketing plan', 1, '[]'))
            c.execute('''
                INSERT INTO chat_history (id, session_id, timestamp, message, is_user, reactions)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (str(uuid.uuid4()), session_id, datetime.utcnow().isoformat(), response, 0, '[]'))
            conn.commit()

        resp = jsonify({'response': response, 'session_id': session_id})
        resp.set_cookie('session_id', session_id, max_age=3600, httponly=True, samesite='Strict')
        return resp

    except Exception as e:
        logger.error(f"Plan error: {str(e)}")
        return jsonify({'response': f'Sorry, I encountered an error: {str(e)}', 'session_id': session_id}), 500

@app.route('/integrate', methods=['POST'])
def integrate_tool():
    try:
        data = request.json
        session_id = request.cookies.get('session_id') or str(uuid.uuid4())
        tool = data.get('tool')

        if not tool:
            return jsonify({'response': 'No tool specified', 'session_id': session_id}), 400

        # Placeholder for Google Analytics integration
        response = f"Integration with {tool} is not yet implemented. Please provide API credentials to fetch data."
        
        with sqlite3.connect(DB_FILE) as conn:
            c = conn.cursor()
            c.execute('''
                INSERT INTO chat_history (id, session_id, timestamp, message, is_user, reactions)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (str(uuid.uuid4()), session_id, datetime.utcnow().isoformat(), f"Fetching {tool} data", 1, '[]'))
            c.execute('''
                INSERT INTO chat_history (id, session_id, timestamp, message, is_user, reactions)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (str(uuid.uuid4()), session_id, datetime.utcnow().isoformat(), response, 0, '[]'))
            conn.commit()

        resp = jsonify({'response': response, 'session_id': session_id})
        resp.set_cookie('session_id', session_id, max_age=3600, httponly=True, samesite='Strict')
        return resp

    except Exception as e:
        logger.error(f"Integration error: {str(e)}")
        return jsonify({'response': f'Sorry, I encountered an error: {str(e)}', 'session_id': session_id}), 500

@app.route('/reminder', methods=['POST'])
def set_reminder():
    try:
        data = request.json
        session_id = request.cookies.get('session_id') or str(uuid.uuid4())
        task = data.get('task')
        time = data.get('time')

        if not task or not time:
            return jsonify({'response': 'Task and time are required', 'session_id': session_id}), 400

        reminder_id = str(uuid.uuid4())
        with sqlite3.connect(DB_FILE) as conn:
            c = conn.cursor()
            c.execute('''
                INSERT INTO reminders (id, session_id, task, time)
                VALUES (?, ?, ?, ?)
            ''', (reminder_id, session_id, task, time))
            conn.commit()

        response = f"Reminder set for '{task}' at {time}"
        resp = jsonify({'response': response, 'session_id': session_id})
        resp.set_cookie('session_id', session_id, max_age=3600, httponly=True, samesite='Strict')
        return resp

    except Exception as e:
        logger.error(f"Reminder error: {str(e)}")
        return jsonify({'response': f'Sorry, I encountered an error: {str(e)}', 'session_id': session_id}), 500

def cleanup_old_sessions():
    cutoff = (datetime.utcnow() - timedelta(hours=1)).isoformat()
    with sqlite3.connect(DB_FILE) as conn:
        c = conn.cursor()
        c.execute('''
            DELETE FROM chat_history
            WHERE session_id IN (
                SELECT session_id FROM chat_history
                WHERE timestamp < ?
                GROUP BY session_id
            )
        ''', (cutoff,))
        c.execute('''
            DELETE FROM user_profiles
            WHERE session_id NOT IN (
                SELECT DISTINCT session_id FROM chat_history
            )
        ''')
        c.execute('''
            DELETE FROM reminders
            WHERE session_id NOT IN (
                SELECT DISTINCT session_id FROM chat_history
            )
        ''')
        conn.commit()
    logger.info("Cleaned up old sessions")

if __name__ == '__main__':
    app.run(debug=True, load_dotenv=False)